# pyiron_nodes

## Overview

This repository collects a sample pyiron_nodes for pyiron_workflows with a focus on atomistic workflows. It also includes utility nodes related to plotting functionality or numpy functions. It provides best practice example nodes and corresponding data classes. This repo is open for additional categories and nodes. 


