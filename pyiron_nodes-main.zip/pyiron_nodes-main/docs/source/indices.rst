.. _indices:


API Documentation
=================

* :ref:`genindex`
* :ref:`modindex`


.. toctree::
   :maxdepth: 2
