.. _examples:


Example Notebooks
=================

.. nbgallery::
   :maxdepth: 2
   :glob:

   notebooks/*