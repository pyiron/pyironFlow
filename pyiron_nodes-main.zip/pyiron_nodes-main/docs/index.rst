.. pyiron_nodes documentation master file

.. _index:

.. include:: README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :hidden:

   source/examples.rst
   source/indices.rst