---
name: Feature request
about: Make a suggestion for a new feature or a change to pyiron_nodes
title: ''
labels: enhancement
assignees: ''

---

**Summary**

<!--Please provide a brief and concise description of the suggested feature or change-->

**Detailed Description**

<!--Please explain how you would like to see pyiron_nodes enhanced, what feature(s) you are looking for, what specific problems this will solve.-->

**Further Information, Files, and Links**

<!--Put any additional information here, attach relevant text or image files and URLs to external sites, e.g. relevant publications-->
