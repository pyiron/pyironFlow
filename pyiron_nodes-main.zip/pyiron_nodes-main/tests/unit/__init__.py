"""
Small tests run, relatively fast tests for checking individual bits of the code base.
"""