"""
Timed tests to make sure critical components stay sufficiently efficient.
"""