import unittest


class TestNothing(unittest.TestCase):
    def test_nothing(self):
        self.assertTrue(True)
