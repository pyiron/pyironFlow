"""
Large and potentially slower tests to check how the pieces fit together.
"""